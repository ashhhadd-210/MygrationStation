"use client";

import { useState, useCallback, useTransition } from "react";
import { useTranslations } from "next-intl";
import type { FormationDraft } from "@/lib/supabase/database.types";
import { saveFormationDraft } from "../actions";
import { ProgressBar } from "./ProgressBar";
import { Step1Residency } from "./Step1Residency";
import { Step2State } from "./Step2State";
import { Step3BusinessName } from "./Step3BusinessName";
import { Step4Owners } from "./Step4Owners";
import { Step5RegisteredAgent } from "./Step5RegisteredAgent";
import { Step6Review } from "./Step6Review";
import { Step7Payment } from "./Step7Payment";
import { Step8Confirmation } from "./Step8Confirmation";

interface FormationWizardProps {
  businessId: string;
  initialDraft: FormationDraft;
}

export function FormationWizard({
  businessId,
  initialDraft,
}: FormationWizardProps) {
  const t = useTranslations("formation");
  const common = useTranslations("common");

  const [draft, setDraft] = useState<FormationDraft>(initialDraft);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const [showRestored, setShowRestored] = useState(initialDraft.currentStep > 1);

  const currentStep = draft.currentStep;
  const TOTAL_STEPS = 8;

  /**
   * Persist draft to Supabase after each step change.
   */
  const persistDraft = useCallback(
    (updatedDraft: FormationDraft) => {
      startTransition(async () => {
        setSaveError(null);
        const result = await saveFormationDraft(businessId, updatedDraft);
        if (!result.success) {
          setSaveError(result.error ?? common("errorGeneric"));
        }
      });
    },
    [businessId, common]
  );

  /**
   * Advance to next step. Merges step data into draft first.
   */
  function goNext(stepData: Partial<FormationDraft> = {}) {
    const updated: FormationDraft = {
      ...draft,
      ...stepData,
      currentStep: Math.min(currentStep + 1, TOTAL_STEPS),
    };
    setDraft(updated);
    persistDraft(updated);
    setShowRestored(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  /**
   * Go back to previous step.
   */
  function goBack() {
    if (currentStep <= 1) return;
    const updated: FormationDraft = {
      ...draft,
      currentStep: currentStep - 1,
    };
    setDraft(updated);
    persistDraft(updated);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  /**
   * Jump to a specific step (used by Review step's edit buttons).
   */
  function goToStep(step: number) {
    const updated: FormationDraft = { ...draft, currentStep: step };
    setDraft(updated);
    persistDraft(updated);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const stepProps = {
    draft,
    businessId,
    onNext: goNext,
    onBack: goBack,
    isPending,
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-slate-900">{t("title")}</h1>
        <p className="mt-1 text-sm text-slate-500">{t("subtitle")}</p>
      </div>

      <ProgressBar currentStep={currentStep} totalSteps={TOTAL_STEPS} />

      {/* Restored draft notice */}
      {showRestored && (
        <div className="mb-4 rounded-lg bg-blue-50 p-3 text-sm text-blue-700">
          {t("draftRestored")}
          <button
            onClick={() => setShowRestored(false)}
            className="ms-2 font-medium underline"
          >
            {common("close")}
          </button>
        </div>
      )}

      {/* Save error */}
      {saveError && (
        <div className="mb-4 rounded-lg bg-danger-50 p-3 text-sm text-danger-700">
          {saveError}
        </div>
      )}

      {/* Saving indicator */}
      {isPending && (
        <div className="mb-4 text-xs text-slate-400">{t("progressSaved")}</div>
      )}

      {/* Step content */}
      <div className="card animate-fade-in">
        {currentStep === 1 && <Step1Residency {...stepProps} />}
        {currentStep === 2 && <Step2State {...stepProps} />}
        {currentStep === 3 && <Step3BusinessName {...stepProps} />}
        {currentStep === 4 && <Step4Owners {...stepProps} />}
        {currentStep === 5 && <Step5RegisteredAgent {...stepProps} />}
        {currentStep === 6 && (
          <Step6Review {...stepProps} onGoToStep={goToStep} />
        )}
        {currentStep === 7 && <Step7Payment {...stepProps} />}
        {currentStep === 8 && <Step8Confirmation {...stepProps} />}
      </div>

      {/* Legal disclaimer */}
      <p className="prose-legal mt-6 text-center">
        {common("legalDisclaimer")}
      </p>
    </div>
  );
}
