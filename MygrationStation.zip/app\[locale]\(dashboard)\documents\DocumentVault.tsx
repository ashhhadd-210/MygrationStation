"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { Button } from "@/components/ui/Button";
import { formatDate } from "@/lib/utils";
import {
  getDocumentSignedUrl,
  createShareableLink,
  uploadDocument,
  deleteDocument,
} from "./actions";
import type { DocumentType } from "@/lib/supabase/database.types";

interface Document {
  id: string;
  document_type: DocumentType;
  display_name: string;
  source: string;
  storage_path: string;
  file_size_bytes: number | null;
  mime_type: string | null;
  expires_at: string | null;
  created_at: string;
  business_id: string | null;
}

interface Business {
  id: string;
  name: string;
}

interface DocumentVaultProps {
  documents: Document[];
  businesses: Business[];
}

const CATEGORY_ICONS: Record<string, string> = {
  articles_of_organization: "📄",
  operating_agreement: "📋",
  ein_letter: "🏛️",
  boi_confirmation: "🔍",
  form_5472_kit: "📊",
  annual_report: "📅",
  passport: "🛂",
  itin_letter: "💳",
  third_party_auth: "✍️",
  bank_statement: "🏦",
  business_license: "📜",
  contract: "📝",
  other: "📎",
};

export function DocumentVault({ documents, businesses }: DocumentVaultProps) {
  const t = useTranslations("documents");
  const common = useTranslations("common");
  const router = useRouter();

  const [filter, setFilter] = useState<DocumentType | "all">("all");
  const [showUpload, setShowUpload] = useState(false);
  const [isPending, startTransition] = useTransition();

  const filtered =
    filter === "all"
      ? documents
      : documents.filter((d) => d.document_type === filter);

  const categories = Array.from(
    new Set(documents.map((d) => d.document_type))
  );

  async function handleView(storagePath: string) {
    startTransition(async () => {
      const result = await getDocumentSignedUrl(storagePath);
      if ("url" in result) {
        window.open(result.url, "_blank");
      }
    });
  }

  async function handleShare(storagePath: string, hours: 24 | 72) {
    startTransition(async () => {
      const result = await createShareableLink(storagePath, hours);
      if ("url" in result) {
        await navigator.clipboard.writeText(result.url);
        alert(`Link copied! Expires in ${hours} hours.`);
      }
    });
  }

  async function handleDelete(documentId: string) {
    if (!confirm("Are you sure you want to delete this document?")) return;
    startTransition(async () => {
      const result = await deleteDocument(documentId);
      if (result.success) {
        router.refresh();
      }
    });
  }

  function formatSize(bytes: number | null): string {
    if (!bytes) return "";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  }

  return (
    <div className="mt-6">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Category filter */}
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setFilter("all")}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              filter === "all"
                ? "bg-brand-600 text-white"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            All ({documents.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
                filter === cat
                  ? "bg-brand-600 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              {CATEGORY_ICONS[cat] ?? "📎"}{" "}
              {t(`categories.${cat}` as Parameters<typeof t>[0])}
            </button>
          ))}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setShowUpload(!showUpload)}
        >
          {showUpload ? common("cancel") : t("upload")}
        </Button>
      </div>

      {/* Upload form */}
      {showUpload && (
        <UploadForm
          businesses={businesses}
          onComplete={() => {
            setShowUpload(false);
            router.refresh();
          }}
        />
      )}

      {/* Document list */}
      {filtered.length === 0 ? (
        <div className="mt-8 py-12 text-center">
          <p className="text-sm text-slate-400">{t("noDocuments")}</p>
        </div>
      ) : (
        <div className="mt-4 space-y-2">
          {filtered.map((doc) => {
            const isExpiring =
              doc.expires_at &&
              new Date(doc.expires_at).getTime() - Date.now() <
                60 * 24 * 60 * 60 * 1000; // 60 days

            return (
              <div
                key={doc.id}
                className="group flex items-center justify-between rounded-lg border border-slate-200 bg-white p-4 transition-shadow hover:shadow-sm"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">
                    {CATEGORY_ICONS[doc.document_type] ?? "📎"}
                  </span>
                  <div>
                    <p className="font-medium text-slate-900">
                      {doc.display_name}
                    </p>
                    <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span>
                        {t(`categories.${doc.document_type}` as Parameters<typeof t>[0])}
                      </span>
                      <span>&middot;</span>
                      <span>{formatSize(doc.file_size_bytes)}</span>
                      <span>&middot;</span>
                      <span>{formatDate(doc.created_at)}</span>
                      {doc.source === "system_generated" && (
                        <>
                          <span>&middot;</span>
                          <span className="rounded bg-blue-50 px-1.5 py-0.5 text-blue-600">
                            Auto-generated
                          </span>
                        </>
                      )}
                      {isExpiring && (
                        <>
                          <span>&middot;</span>
                          <span className="rounded bg-amber-50 px-1.5 py-0.5 text-amber-600">
                            {t("expiringSoon")}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <Button
                    variant="ghost"
                    size="sm"
                    loading={isPending}
                    onClick={() => handleView(doc.storage_path)}
                  >
                    {common("view")}
                  </Button>
                  <DropdownShare
                    onShare24h={() => handleShare(doc.storage_path, 24)}
                    onShare72h={() => handleShare(doc.storage_path, 72)}
                    label={t("share")}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(doc.id)}
                  >
                    {common("delete")}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function UploadForm({
  businesses,
  onComplete,
}: {
  businesses: Business[];
  onComplete: () => void;
}) {
  const t = useTranslations("documents");
  const common = useTranslations("common");
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function handleSubmit(formData: FormData) {
    setError(null);
    startTransition(async () => {
      const result = await uploadDocument(formData);
      if (!result.success) {
        setError(result.error ?? "Upload failed");
        return;
      }
      onComplete();
    });
  }

  const docTypes: DocumentType[] = [
    "passport",
    "itin_letter",
    "bank_statement",
    "business_license",
    "contract",
    "other",
  ];

  return (
    <form action={handleSubmit} className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="block text-xs font-medium text-slate-600">
            File *
          </label>
          <input
            name="file"
            type="file"
            required
            accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"
            className="mt-1 block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-4 file:py-2 file:text-xs file:font-medium file:text-brand-700 hover:file:bg-brand-100"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-600">
            Document Type *
          </label>
          <select
            name="documentType"
            required
            className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          >
            {docTypes.map((type) => (
              <option key={type} value={type}>
                {t(`categories.${type}` as Parameters<typeof t>[0])}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-600">
            Business
          </label>
          <select
            name="businessId"
            className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">None</option>
            {businesses.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} LLC
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="block text-xs font-medium text-slate-600">
            Display Name
          </label>
          <input
            name="displayName"
            type="text"
            placeholder="Optional custom name"
            className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
      </div>

      {error && (
        <p className="mt-2 text-sm text-danger-700">{error}</p>
      )}

      <div className="mt-4 flex gap-2">
        <Button type="submit" loading={isPending} size="sm">
          {common("upload")}
        </Button>
      </div>
    </form>
  );
}

function DropdownShare({
  onShare24h,
  onShare72h,
  label,
}: {
  onShare24h: () => void;
  onShare72h: () => void;
  label: string;
}) {
  const [open, setOpen] = useState(false);
  const t = useTranslations("documents");

  return (
    <div className="relative">
      <Button variant="ghost" size="sm" onClick={() => setOpen(!open)}>
        {label}
      </Button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute end-0 z-20 mt-1 w-40 rounded-lg border border-slate-200 bg-white py-1 shadow-lg">
            <button
              onClick={() => {
                onShare24h();
                setOpen(false);
              }}
              className="block w-full px-3 py-1.5 text-start text-xs text-slate-700 hover:bg-slate-50"
            >
              {t("share24h")}
            </button>
            <button
              onClick={() => {
                onShare72h();
                setOpen(false);
              }}
              className="block w-full px-3 py-1.5 text-start text-xs text-slate-700 hover:bg-slate-50"
            >
              {t("share72h")}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
