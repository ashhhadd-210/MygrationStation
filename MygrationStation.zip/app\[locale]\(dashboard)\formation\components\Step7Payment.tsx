"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { STATES } from "@/lib/constants/states";
import { formatCents } from "@/lib/utils";
import { createFormationCheckoutSession } from "../actions";
import type { StepProps } from "./types";

export function Step7Payment({ draft, onBack, businessId }: StepProps) {
  const t = useTranslations("formation.step7");
  const common = useTranslations("common");

  const [plan, setPlan] = useState<"formation_only" | "formation_ein">(
    draft.selectedPlan ?? "formation_ein"
  );
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const stateConfig = draft.stateCode ? STATES[draft.stateCode] : null;
  const stateFee = stateConfig?.filingFeeCents ?? 0;

  function handleProceedToPayment() {
    setError(null);
    startTransition(async () => {
      const result = await createFormationCheckoutSession(businessId, plan);
      if ("error" in result) {
        setError(result.error);
        return;
      }
      // Redirect to Stripe Checkout
      window.location.href = result.url;
    });
  }

  const plans: Array<{
    id: "formation_only" | "formation_ein";
    title: string;
    price: string;
    description: string;
    includes: string[];
    recommended: boolean;
  }> = [
    {
      id: "formation_only",
      title: t("formationOnly"),
      price: t("formationOnlyPrice"),
      description: t("formationOnlyDescription"),
      includes: t.raw("formationOnlyIncludes") as string[],
      recommended: false,
    },
    {
      id: "formation_ein",
      title: t("formationEIN"),
      price: t("formationEINPrice"),
      description: t("formationEINDescription"),
      includes: t.raw("formationEINIncludes") as string[],
      recommended: true,
    },
  ];

  return (
    <div>
      <h2 className="text-xl font-semibold text-slate-900">{t("title")}</h2>
      <p className="mt-1 text-sm text-slate-500">{t("description")}</p>

      {/* Plan cards */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {plans.map((p) => (
          <button
            key={p.id}
            onClick={() => setPlan(p.id)}
            className={`relative rounded-xl border-2 p-5 text-start transition-colors ${
              plan === p.id
                ? "border-brand-500 bg-brand-50"
                : "border-slate-200 hover:border-slate-300"
            }`}
          >
            {p.recommended && (
              <span className="absolute -top-2.5 end-3 rounded-full bg-brand-600 px-3 py-0.5 text-[10px] font-semibold text-white">
                Recommended
              </span>
            )}
            <h3 className="text-lg font-bold text-slate-900">{p.title}</h3>
            <p className="text-2xl font-bold text-brand-700">{p.price}</p>
            <p className="mt-1 text-xs text-slate-500">
              {t("stateFee", {
                amount: formatCents(stateFee),
              })}
            </p>
            <p className="mt-2 text-sm text-slate-600">{p.description}</p>
            <ul className="mt-3 space-y-1.5">
              {p.includes.map((item, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-2 text-sm text-slate-600"
                >
                  <svg
                    className="mt-0.5 h-4 w-4 flex-shrink-0 text-green-500"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  {item}
                </li>
              ))}
            </ul>
          </button>
        ))}
      </div>

      {/* Total */}
      <div className="mt-6 rounded-lg bg-slate-50 p-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">
            {plan === "formation_only" ? "Formation Only" : "Formation + EIN"}
          </span>
          <span className="font-semibold text-slate-900">
            {formatCents(plan === "formation_only" ? 14900 : 24900)}
          </span>
        </div>
        <div className="mt-1 flex items-center justify-between text-sm">
          <span className="text-slate-600">
            {stateConfig?.stateName} filing fee
          </span>
          <span className="font-semibold text-slate-900">
            {formatCents(stateFee)}
          </span>
        </div>
        <div className="mt-2 border-t border-slate-200 pt-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-900">Total</span>
            <span className="text-lg font-bold text-slate-900">
              {formatCents(
                (plan === "formation_only" ? 14900 : 24900) + stateFee
              )}
            </span>
          </div>
        </div>
      </div>

      {error && (
        <div className="mt-4 rounded-lg bg-danger-50 p-3 text-sm text-danger-700">
          {error}
        </div>
      )}

      {/* Navigation */}
      <div className="mt-8 flex justify-between">
        <button
          onClick={onBack}
          className="rounded-lg border border-slate-300 px-6 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
        >
          {common("back")}
        </button>
        <button
          onClick={handleProceedToPayment}
          disabled={isPending}
          className="rounded-lg bg-brand-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isPending ? common("loading") : t("proceedToPayment")}
        </button>
      </div>

      <p className="mt-3 text-center text-xs text-slate-400">
        {t("stripeSecure")}
      </p>
    </div>
  );
}
