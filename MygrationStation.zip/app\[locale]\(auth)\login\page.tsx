"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const t = useTranslations("auth");
  const common = useTranslations("common");

  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const supabase = createClient();
      const { error: authError } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: `${window.location.origin}/en/callback`,
        },
      });

      if (authError) {
        setError(authError.message);
        return;
      }
      setSent(true);
    } catch {
      setError(common("errorGeneric"));
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50/70 px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 flex justify-center">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-600">
              <span className="text-sm font-bold text-white">H1</span>
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">
              {common("appName")}
            </span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-100 bg-white p-8 shadow-card">
          {sent ? (
            <div className="text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50">
                <svg
                  className="h-7 w-7 text-brand-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={1.5}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"
                  />
                </svg>
              </div>
              <h2 className="mt-5 text-xl font-bold text-slate-900">
                {t("checkEmail")}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-slate-500">
                {t("magicLinkDescription", { email })}
              </p>
            </div>
          ) : (
            <>
              <div className="text-center">
                <h2 className="text-xl font-bold text-slate-900">
                  Welcome back
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  Sign in to your H1Boss account
                </p>
              </div>

              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-slate-700"
                  >
                    {t("email")}
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t("emailPlaceholder")}
                    className="mt-1.5 block w-full rounded-xl border border-slate-200 px-4 py-2.5 text-slate-900 placeholder:text-slate-400 transition-colors focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
                  />
                </div>

                {error && (
                  <div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading || !email}
                  className="w-full rounded-xl bg-brand-600 py-2.5 text-sm font-semibold text-white shadow-sm transition-all hover:bg-brand-700 hover:shadow-md disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {isLoading ? common("loading") : t("signIn")}
                </button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-sm text-slate-500">
                  {t("noAccount")}{" "}
                  <Link
                    href="/signup"
                    className="font-medium text-brand-600 hover:text-brand-700"
                  >
                    {t("signUp")}
                  </Link>
                </p>
              </div>
            </>
          )}
        </div>

        <div className="mt-6 space-y-2">
          <p className="text-center text-xs text-slate-400">
            {t("privacyNotice")}
          </p>
          <p className="prose-legal text-center">{common("legalDisclaimer")}</p>
        </div>
      </div>
    </div>
  );
}
