"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { createClient } from "@/lib/supabase/client";
import { localeNames, type Locale } from "@/i18n/config";

export default function OnboardingPage() {
  const t = useTranslations("onboarding");
  const common = useTranslations("common");
  const router = useRouter();

  const [countryOfBirth, setCountryOfBirth] = useState("");
  const [langPref, setLangPref] = useState<Locale>("en");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const supabase = createClient();

      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const { error: updateError } = await supabase
        .from("users")
        .update({
          country_of_birth: countryOfBirth || null,
          lang_pref: langPref,
        })
        .eq("id", user.id);

      if (updateError) {
        setError(updateError.message);
        return;
      }

      // Set locale cookie for next-intl
      document.cookie = `NEXT_LOCALE=${langPref};path=/;max-age=31536000`;

      router.push("/dashboard");
    } catch {
      setError(common("errorGeneric"));
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md">
        <div className="rounded-xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-2xl font-bold text-slate-900">{t("title")}</h2>
          <p className="mt-1 text-sm text-slate-500">{t("subtitle")}</p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            {/* Country of Birth */}
            <div>
              <label
                htmlFor="country"
                className="block text-sm font-medium text-slate-700"
              >
                {t("countryOfBirth")}
              </label>
              <p className="mt-0.5 text-xs text-slate-500">
                {t("countryOfBirthDescription")}
              </p>
              <input
                id="country"
                type="text"
                value={countryOfBirth}
                onChange={(e) => setCountryOfBirth(e.target.value)}
                placeholder="Mexico, China, India, Philippines..."
                className="mt-1 block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
              />
            </div>

            {/* Language Confirmation */}
            <div>
              <label
                htmlFor="langPref"
                className="block text-sm font-medium text-slate-700"
              >
                {t("confirmLanguage")}
              </label>
              <p className="mt-0.5 text-xs text-slate-500">
                {t("confirmLanguageDescription")}
              </p>
              <select
                id="langPref"
                value={langPref}
                onChange={(e) => setLangPref(e.target.value as Locale)}
                className="mt-1 block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-slate-900 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
              >
                {Object.entries(localeNames).map(([code, name]) => (
                  <option key={code} value={code}>
                    {name}
                  </option>
                ))}
              </select>
            </div>

            {error && (
              <div className="rounded-lg bg-danger-50 p-3 text-sm text-danger-700">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isLoading ? common("loading") : t("letsGetStarted")}
            </button>
          </form>
        </div>
        <p className="prose-legal mt-4 text-center">
          {common("privacyPledge")}
        </p>
      </div>
    </div>
  );
}
