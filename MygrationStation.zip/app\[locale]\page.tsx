import { useTranslations } from "next-intl";
import { setRequestLocale } from "next-intl/server";
import { Link } from "@/i18n/navigation";

interface PageProps {
  params: Promise<{ locale: string }>;
}

export default async function HomePage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);

  return <HomeContent />;
}

function HomeContent() {
  const t = useTranslations("common");
  const pricing = useTranslations("pricing");

  return (
    <div className="flex min-h-screen flex-col bg-white">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-slate-100/80 bg-white/90 backdrop-blur-lg">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600">
              <span className="text-sm font-bold text-white">H1</span>
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-900">
              {t("appName")}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="rounded-xl px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:text-slate-900"
            >
              Sign In
            </Link>
            <Link
              href="/signup"
              className="rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-medium text-white shadow-sm transition-all hover:bg-brand-700 hover:shadow-md"
            >
              Get Started
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <main className="flex-1">
        <section className="relative overflow-hidden">
          {/* Subtle gradient background */}
          <div className="absolute inset-0 bg-gradient-to-b from-brand-50/40 via-white to-white" />
          <div className="relative mx-auto max-w-4xl px-6 pb-20 pt-24 text-center sm:pt-32">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-sm font-medium text-brand-700">
              <span className="inline-block h-2 w-2 rounded-full bg-brand-500" />
              Now available in 10 languages
            </div>
            <h1 className="text-balance text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
              {t("tagline")}
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-slate-500">
              Form a US LLC in any state, get your EIN without an SSN, and stay
              compliant with automated deadline tracking. Built for immigrants,
              by immigrants.
            </p>
            <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Link
                href="/signup"
                className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-8 py-3.5 text-base font-semibold text-white shadow-sm transition-all hover:bg-brand-700 hover:shadow-md"
              >
                Start Your LLC
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                </svg>
              </Link>
              <Link
                href="/login"
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-8 py-3.5 text-base font-semibold text-slate-700 transition-all hover:bg-slate-50 hover:border-slate-300"
              >
                Sign In
              </Link>
            </div>
            <p className="mt-8 text-sm text-slate-400">{t("privacyPledge")}</p>
          </div>
        </section>

        {/* Trust signals */}
        <section className="border-y border-slate-100 bg-slate-50/50 py-10">
          <div className="mx-auto max-w-5xl px-6">
            <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
              <TrustItem number="50" label="States supported" />
              <TrustItem number="10" label="Languages" />
              <TrustItem number="256" label="Bit encryption" />
              <TrustItem number="24/7" label="Compliance monitoring" />
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="py-20">
          <div className="mx-auto max-w-5xl px-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
                LLC formation in 3 steps
              </h2>
              <p className="mt-3 text-slate-500">
                We handle the paperwork. You focus on your business.
              </p>
            </div>
            <div className="mt-14 grid gap-8 sm:grid-cols-3">
              <StepCard
                step="1"
                title="Tell us about your business"
                description="Choose your state, name your LLC, and provide owner details. Our wizard guides you through every field."
              />
              <StepCard
                step="2"
                title="We file everything"
                description="Articles of Organization, Operating Agreement, EIN application, and BOI report — we prepare and file it all."
              />
              <StepCard
                step="3"
                title="Stay compliant"
                description="Automated compliance calendar tracks deadlines. Get alerts before penalties hit. Never miss an annual report."
              />
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section className="border-t border-slate-100 bg-slate-50/50 py-20">
          <div className="mx-auto max-w-5xl px-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
                Simple, transparent pricing
              </h2>
              <p className="mt-3 text-slate-500">No hidden fees. No upsells.</p>
            </div>
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              <PriceCard
                title={pricing("formationOnly")}
                price={pricing("formationOnlyPrice")}
                note={pricing("plusStateFees")}
                cta={t("signUp")}
              />
              <PriceCard
                title={pricing("formationEIN")}
                price={pricing("formationEINPrice")}
                note={pricing("plusStateFees")}
                highlighted
                cta={t("signUp")}
              />
              <PriceCard
                title={pricing("complianceAnnual")}
                price={pricing("complianceAnnualPrice")}
                cta={t("signUp")}
              />
              <PriceCard
                title={pricing("bankingAssist")}
                price={pricing("bankingAssistPrice")}
                cta={t("signUp")}
              />
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-100 bg-white py-10">
        <div className="mx-auto max-w-6xl px-6">
          <div className="flex items-center justify-center gap-2.5">
            <div className="flex h-6 w-6 items-center justify-center rounded-md bg-brand-600">
              <span className="text-[10px] font-bold text-white">H1</span>
            </div>
            <span className="text-sm font-semibold text-slate-900">H1Boss</span>
          </div>
          <p className="prose-legal mt-4 text-center">{t("legalDisclaimer")}</p>
          <p className="mt-2 text-center text-xs text-slate-400">
            &copy; {new Date().getFullYear()} H1Boss. {t("poweredBy")}
          </p>
        </div>
      </footer>
    </div>
  );
}

function TrustItem({ number, label }: { number: string; label: string }) {
  return (
    <div className="text-center">
      <p className="text-2xl font-bold text-brand-700">{number}</p>
      <p className="mt-1 text-xs font-medium text-slate-500">{label}</p>
    </div>
  );
}

function StepCard({
  step,
  title,
  description,
}: {
  step: string;
  title: string;
  description: string;
}) {
  return (
    <div className="relative rounded-2xl border border-slate-100 bg-white p-6 shadow-card">
      <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-sm font-bold text-brand-700">
        {step}
      </div>
      <h3 className="text-base font-semibold text-slate-900">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-slate-500">{description}</p>
    </div>
  );
}

function PriceCard({
  title,
  price,
  note,
  highlighted = false,
  cta,
}: {
  title: string;
  price: string;
  note?: string;
  highlighted?: boolean;
  cta: string;
}) {
  return (
    <div
      className={`flex flex-col rounded-2xl border p-6 transition-all ${
        highlighted
          ? "border-brand-200 bg-brand-50/50 shadow-card-hover ring-1 ring-brand-100"
          : "border-slate-100 bg-white shadow-card hover:shadow-card-hover"
      }`}
    >
      {highlighted && (
        <span className="mb-3 inline-block self-start rounded-full bg-brand-600 px-3 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white">
          Most popular
        </span>
      )}
      <h3 className="text-sm font-semibold text-slate-900">{title}</h3>
      <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900">{price}</p>
      {note && <p className="mt-1 text-xs text-slate-400">{note}</p>}
      <Link
        href="/signup"
        className={`mt-5 block rounded-lg py-2 text-center text-sm font-semibold transition-colors ${
          highlighted
            ? "bg-brand-600 text-white hover:bg-brand-700"
            : "bg-slate-100 text-slate-700 hover:bg-slate-200"
        }`}
      >
        {cta}
      </Link>
    </div>
  );
}
