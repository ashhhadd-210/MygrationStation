"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { createClient } from "@/lib/supabase/client";
import type { ResidencyStatus } from "@/lib/supabase/database.types";
import { localeNames, type Locale } from "@/i18n/config";

type SignupStep = "form" | "check_email";

export default function SignupPage() {
  const t = useTranslations("auth");
  const common = useTranslations("common");

  const [step, setStep] = useState<SignupStep>("form");
  const [email, setEmail] = useState("");
  const [residencyStatus, setResidencyStatus] =
    useState<ResidencyStatus>("itin_holder");
  const [langPref, setLangPref] = useState<Locale>("en");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const supabase = createClient();

      const { error: authError } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: `${window.location.origin}/${langPref}/callback?residency=${residencyStatus}&lang=${langPref}`,
          data: {
            residency_status: residencyStatus,
            lang_pref: langPref,
          },
        },
      });

      if (authError) {
        setError(authError.message);
        return;
      }

      setStep("check_email");
    } catch {
      setError(common("errorGeneric"));
    } finally {
      setIsLoading(false);
    }
  }

  if (step === "check_email") {
    return (
      <AuthShell>
        <div className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-brand-100">
            <svg
              className="h-8 w-8 text-brand-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
              />
            </svg>
          </div>
          <h2 className="mt-4 text-xl font-bold text-slate-900">
            {t("checkEmail")}
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            {t("magicLinkDescription", { email })}
          </p>
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell>
      <h2 className="text-2xl font-bold text-slate-900">{t("signUp")}</h2>
      <p className="mt-1 text-sm text-slate-500">
        {common("tagline")}
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        {/* Email */}
        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-slate-700"
          >
            {t("email")}
          </label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={t("emailPlaceholder")}
            className="mt-1 block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
          />
        </div>

        {/* Residency Status */}
        <div>
          <label className="block text-sm font-medium text-slate-700">
            {t("residencyStatus")}
          </label>
          <p className="mt-0.5 text-xs text-slate-500">
            {t("residencyStatusDescription")}
          </p>
          <div className="mt-3 space-y-2">
            {(
              ["ssn_holder", "itin_holder", "non_resident"] as const
            ).map((status) => (
              <label
                key={status}
                className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 transition-colors ${
                  residencyStatus === status
                    ? "border-brand-300 bg-brand-50"
                    : "border-slate-200 hover:bg-slate-50"
                }`}
              >
                <input
                  type="radio"
                  name="residencyStatus"
                  value={status}
                  checked={residencyStatus === status}
                  onChange={() => setResidencyStatus(status)}
                  className="mt-0.5 h-4 w-4 text-brand-600 focus:ring-brand-500"
                />
                <span className="text-sm text-slate-700">
                  {t(`residencyOptions.${status}`)}
                </span>
              </label>
            ))}
          </div>
        </div>

        {/* Language Preference */}
        <div>
          <label
            htmlFor="langPref"
            className="block text-sm font-medium text-slate-700"
          >
            {t("languagePreference")}
          </label>
          <select
            id="langPref"
            value={langPref}
            onChange={(e) => setLangPref(e.target.value as Locale)}
            className="mt-1 block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-slate-900 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
          >
            {Object.entries(localeNames).map(([code, name]) => (
              <option key={code} value={code}>
                {name}
              </option>
            ))}
          </select>
        </div>

        {/* Privacy notice */}
        <div className="rounded-lg bg-green-50 p-3">
          <p className="flex items-start gap-2 text-xs text-green-800">
            <svg
              className="mt-0.5 h-4 w-4 flex-shrink-0"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z"
                clipRule="evenodd"
              />
            </svg>
            {t("privacyNotice")}
          </p>
        </div>

        {error && (
          <div className="rounded-lg bg-danger-50 p-3 text-sm text-danger-700">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading || !email}
          className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isLoading ? common("loading") : t("signUp")}
        </button>

        <p className="text-center text-xs text-slate-500">
          {t("termsAgreement")}
        </p>
      </form>

      <p className="mt-6 text-center text-sm text-slate-600">
        {t("hasAccount")}{" "}
        <Link href="/login" className="font-medium text-brand-600 hover:text-brand-700">
          {t("signIn")}
        </Link>
      </p>
    </AuthShell>
  );
}

function AuthShell({ children }: { children: React.ReactNode }) {
  const common = useTranslations("common");
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <span className="text-2xl font-bold text-brand-700">
            {common("appName")}
          </span>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-8 shadow-sm">
          {children}
        </div>
        <p className="prose-legal mt-4 text-center">
          {common("legalDisclaimer")}
        </p>
      </div>
    </div>
  );
}
