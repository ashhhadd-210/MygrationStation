"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/Button";
import { localeNames, type Locale } from "@/i18n/config";

export default function SettingsPage() {
  const common = useTranslations("common");
  const router = useRouter();

  const [langPref, setLangPref] = useState<Locale>("en");
  const [isPending, startTransition] = useTransition();
  const [saved, setSaved] = useState(false);

  function handleSave() {
    startTransition(async () => {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from("users")
        .update({ lang_pref: langPref })
        .eq("id", user.id);

      document.cookie = `NEXT_LOCALE=${langPref};path=/;max-age=31536000`;
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    });
  }

  async function handleDeleteAccount() {
    if (
      !confirm(
        "Are you sure you want to delete your account? This action is irreversible and will delete all your data."
      )
    )
      return;

    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="text-2xl font-bold text-slate-900">Settings</h1>

      {/* Language */}
      <div className="mt-8 card">
        <h2 className="text-lg font-semibold text-slate-900">Language Preference</h2>
        <p className="mt-1 text-sm text-slate-500">
          Change the language for all communications and the interface.
        </p>
        <select
          value={langPref}
          onChange={(e) => setLangPref(e.target.value as Locale)}
          className="mt-3 block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm"
        >
          {Object.entries(localeNames).map(([code, name]) => (
            <option key={code} value={code}>
              {name}
            </option>
          ))}
        </select>
        <div className="mt-4 flex items-center gap-3">
          <Button onClick={handleSave} loading={isPending}>
            {common("save")}
          </Button>
          {saved && (
            <span className="text-sm text-green-600">Saved!</span>
          )}
        </div>
      </div>

      {/* Privacy */}
      <div className="mt-6 card">
        <h2 className="text-lg font-semibold text-slate-900">Privacy</h2>
        <div className="mt-3 rounded-lg bg-green-50 p-4">
          <p className="text-sm text-green-800">{common("privacyPledge")}</p>
        </div>
      </div>

      {/* Danger zone */}
      <div className="mt-6 rounded-xl border-2 border-danger-500 bg-danger-50 p-6">
        <h2 className="text-lg font-semibold text-danger-700">Danger Zone</h2>
        <p className="mt-1 text-sm text-danger-700">
          Deleting your account removes all data, documents, and business records permanently.
        </p>
        <Button
          variant="danger"
          size="sm"
          className="mt-4"
          onClick={handleDeleteAccount}
        >
          Delete my account
        </Button>
      </div>

      <p className="prose-legal mt-8 text-center">{common("legalDisclaimer")}</p>
    </div>
  );
}
