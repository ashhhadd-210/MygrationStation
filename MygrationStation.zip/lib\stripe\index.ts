/**
 * Stripe pricing configuration.
 * Replace placeholder IDs with real Stripe Price IDs from your dashboard.
 */

export const STRIPE_PRICES = {
  formation_only: {
    priceId: process.env.STRIPE_PRICE_FORMATION_ONLY ?? "price_placeholder_formation",
    amountCents: 14900,
    label: "LLC Formation Only",
  },
  formation_ein: {
    priceId: process.env.STRIPE_PRICE_FORMATION_EIN ?? "price_placeholder_formation_ein",
    amountCents: 24900,
    label: "LLC Formation + EIN Concierge",
  },
  compliance_annual: {
    priceId: process.env.STRIPE_PRICE_COMPLIANCE_ANNUAL ?? "price_placeholder_compliance",
    amountCents: 19900,
    label: "Compliance Annual",
    interval: "year" as const,
  },
  banking_assist: {
    priceId: process.env.STRIPE_PRICE_BANKING_ASSIST ?? "price_placeholder_banking",
    amountCents: 4900,
    label: "Banking Assist Add-on",
  },
} as const;

export type StripePlan = keyof typeof STRIPE_PRICES;
