"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { STATES } from "@/lib/constants/states";
import { initiateArticlesSigning } from "../actions";
import type { StepProps } from "./types";

interface Step6Props extends StepProps {
  onGoToStep: (step: number) => void;
}

export function Step6Review({ draft, onNext, onBack, onGoToStep, businessId }: Step6Props) {
  const t = useTranslations("formation.step6");
  const common = useTranslations("common");

  const [signed, setSigned] = useState(draft.signatureCompleted ?? false);
  const [signingInProgress, startSigning] = useTransition();
  const [_signError, setSignError] = useState<string | null>(null);

  const stateConfig = draft.stateCode ? STATES[draft.stateCode] : null;

  function handleSignArticles() {
    setSignError(null);
    startSigning(async () => {
      const result = await initiateArticlesSigning(businessId);
      if ("error" in result) {
        setSignError(result.error);
        return;
      }
      // Redirect to DocuSeal signing page
      // When DocuSeal sends the webhook on completion, our webhook handler
      // updates the draft. When user returns, they'll see signature confirmed.
      window.open(result.signingUrl, "_blank");
      // Optimistically mark as signed since user is redirected to sign.
      // The DocuSeal webhook will confirm this server-side.
      setSigned(true);
    });
  }

  function handleContinue() {
    if (!signed) return;
    onNext({
      signatureCompleted: true,
      docusealSubmissionId: "simulated_submission_id",
    });
  }

  const sections: Array<{
    key: string;
    label: string;
    value: string;
    editStep: number;
  }> = [
    {
      key: "residency",
      label: t("reviewSections.residency"),
      value: draft.residencyStatus ?? "Not set",
      editStep: 1,
    },
    {
      key: "state",
      label: t("reviewSections.state"),
      value: stateConfig
        ? `${stateConfig.stateName} (${stateConfig.stateCode})`
        : "Not set",
      editStep: 2,
    },
    {
      key: "businessName",
      label: t("reviewSections.businessName"),
      value: draft.businessName ? `${draft.businessName} LLC` : "Not set",
      editStep: 3,
    },
    {
      key: "owners",
      label: t("reviewSections.owners"),
      value: draft.members
        ? draft.members
            .map((m) => `${m.fullName} (${m.ownershipPercentage}%)`)
            .join(", ")
        : "Not set",
      editStep: 4,
    },
    {
      key: "registeredAgent",
      label: t("reviewSections.registeredAgent"),
      value:
        draft.registeredAgentChoice === "h1boss"
          ? "H1Boss Registered Agent"
          : draft.ownRegisteredAgent
            ? `${draft.ownRegisteredAgent.name}, ${draft.ownRegisteredAgent.city}`
            : "Not set",
      editStep: 5,
    },
  ];

  return (
    <div>
      <h2 className="text-xl font-semibold text-slate-900">{t("title")}</h2>
      <p className="mt-1 text-sm text-slate-500">{t("description")}</p>

      {/* Review sections */}
      <div className="mt-6 space-y-3">
        {sections.map((section) => (
          <div
            key={section.key}
            className="flex items-start justify-between rounded-lg border border-slate-200 p-4"
          >
            <div>
              <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                {section.label}
              </p>
              <p className="mt-1 text-sm font-medium text-slate-900">
                {section.value}
              </p>
            </div>
            <button
              onClick={() => onGoToStep(section.editStep)}
              className="text-sm font-medium text-brand-600 hover:text-brand-700"
            >
              {t("editSection")}
            </button>
          </div>
        ))}
      </div>

      {/* Foreign-owned notice */}
      {draft.foreignOwned && (
        <div className="mt-4 rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">
          This is a foreign-owned LLC. Additional compliance requirements apply:
          BOI Report (within 30 days) and Form 5472 + Pro-forma 1120 (annually
          by April 15).
        </div>
      )}

      {/* E-signature */}
      <div className="mt-6 rounded-lg border border-slate-200 p-4">
        <h3 className="font-semibold text-slate-900">
          {t("signArticles")}
        </h3>
        <p className="mt-1 text-sm text-slate-500">{t("signDescription")}</p>

        {signed ? (
          <div className="mt-3 flex items-center gap-2 text-sm text-green-700">
            <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z"
                clipRule="evenodd"
              />
            </svg>
            Articles of Organization signed successfully
          </div>
        ) : (
          <button
            onClick={handleSignArticles}
            disabled={signingInProgress}
            className="mt-3 rounded-lg border-2 border-brand-500 bg-brand-50 px-6 py-2.5 text-sm font-semibold text-brand-700 hover:bg-brand-100 disabled:opacity-50"
          >
            {signingInProgress ? "Opening signature pad..." : t("signArticles")}
          </button>
        )}
      </div>

      {/* Navigation */}
      <div className="mt-8 flex justify-between">
        <button
          onClick={onBack}
          className="rounded-lg border border-slate-300 px-6 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
        >
          {common("back")}
        </button>
        <button
          onClick={handleContinue}
          disabled={!signed}
          className="rounded-lg bg-brand-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {common("continue")}
        </button>
      </div>
    </div>
  );
}
